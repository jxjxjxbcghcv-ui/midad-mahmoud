const crypto=require('crypto');
function secret(){return process.env.ADMIN_PASSWORD||''}
function sign(v){return crypto.createHmac('sha256',secret()).update(v).digest('hex')}
function cookie(v){return `midad_admin=${encodeURIComponent(v+'.'+sign(v))}; Path=/; HttpOnly; Secure; SameSite=Lax; Max-Age=604800`}
function verify(req){const raw=req.headers.cookie||'';const m=raw.match(/(?:^|;\s*)midad_admin=([^;]+)/);if(!m)return false;const x=decodeURIComponent(m[1]);const i=x.lastIndexOf('.');if(i<1)return false;const v=x.slice(0,i),sig=x.slice(i+1);return secret()&&crypto.timingSafeEqual(Buffer.from(sig),Buffer.from(sign(v)))}
function requireAdmin(req,res){if(!verify(req)){res.statusCode=401;res.json?res.json({error:'غير مصرح'}):res.end(JSON.stringify({error:'غير مصرح'}));return false}return true}
module.exports={cookie,verify,requireAdmin};
