مِداد محمود — نسخة الأدمن المبسطة

هذه النسخة لا تستخدم Supabase ولا قاعدة بيانات خارجية.
المحتوى محفوظ في ملف site-data.json داخل مستودع GitHub، وكل تعديل من لوحة الأدمن يُحفظ كـ commit في المستودع ثم تعيد Vercel نشر الموقع تلقائيًا.

الإعداد الوحيد المطلوب في Vercel:
1) GITHUB_REPO = jxjxjxbcghcv-ui/midad_mahmoud
2) GITHUB_TOKEN = رمز GitHub بصلاحية Contents: Read and write لهذا المستودع فقط.
3) ADMIN_PASSWORD = كلمة المرور التي تريدها للوحة الأدمن.
4) GITHUB_BRANCH = main (اختياري، ويمكن تركه دون إضافة).

مهم: لا تضع GITHUB_TOKEN داخل ملفات الموقع أو داخل JavaScript الموجود في المتصفح. يوضع فقط في Environment Variables في Vercel.

لوحة الأدمن: /admin.html

بعد ضبط المتغيرات، افتح /admin.html وسجّل بكلمة ADMIN_PASSWORD.
