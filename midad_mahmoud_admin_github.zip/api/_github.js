const API='https://api.github.com';
function cfg(){const [owner,repo]=String(process.env.GITHUB_REPO||'').split('/'); if(!owner||!repo) throw new Error('GITHUB_REPO is missing'); if(!process.env.GITHUB_TOKEN) throw new Error('GITHUB_TOKEN is missing'); return {owner,repo,branch:process.env.GITHUB_BRANCH||'main',token:process.env.GITHUB_TOKEN};}
async function gh(path,options={}){const c=cfg();const r=await fetch(API+'/repos/'+c.owner+'/'+c.repo+path,{...options,headers:{'Accept':'application/vnd.github+json','Authorization':'Bearer '+c.token,'X-GitHub-Api-Version':'2022-11-28','Content-Type':'application/json',...(options.headers||{})}});const t=await r.text();let d;try{d=JSON.parse(t)}catch{d={message:t}}if(!r.ok)throw new Error(d.message||('GitHub '+r.status));return d;}
async function getFile(path){const c=cfg();return gh('/contents/'+path+'?ref='+encodeURIComponent(c.branch));}
async function putFile(path,content,sha,message){const c=cfg();return gh('/contents/'+path,{method:'PUT',body:JSON.stringify({message,content:Buffer.from(content,'utf8').toString('base64'),sha,branch:c.branch})});}
async function putBinary(path,buffer,sha,message){const c=cfg();return gh('/contents/'+path,{method:'PUT',body:JSON.stringify({message,content:buffer.toString('base64'),...(sha?{sha}:{}),branch:c.branch})});}
module.exports={getFile,putFile,putBinary};
