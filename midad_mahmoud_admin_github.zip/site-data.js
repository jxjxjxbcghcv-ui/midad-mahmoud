(function(){
  const esc=s=>String(s??'').replace(/[&<>"']/g,m=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[m]));
  async function load(){
    try{
      const r=await fetch('/api/content',{cache:'no-store'}); if(!r.ok) return;
      const d=await r.json(); const s=d.settings||{};
      const name=document.querySelector('.brand .name'); const sub=document.querySelector('.brand .sub');
      if(name&&s.site_name) name.textContent=s.site_name;
      if(sub&&s.tagline) sub.textContent='— '+s.tagline+' —';
      const cf=document.getElementById('copyrightFooter');
      if(cf) cf.innerHTML=esc(s.copyright_text||'© 2026 مِداد محمود — جميع الحقوق محفوظة')+'<br><span>'+esc(s.owner_notice||'')+'</span>';
      const mark=document.getElementById('profileMark');
      if(mark&&s.profile_url) mark.innerHTML='<img src="'+esc(s.profile_url)+'" alt="" style="width:100%;height:100%;object-fit:cover;border-radius:50%">';
      const about=document.getElementById('aboutText'); if(about&&s.about) about.textContent=s.about;
      if(Array.isArray(d.books)&&d.books.length){
        const box=document.getElementById('dynamicBooks');
        if(box) box.innerHTML=d.books.filter(b=>b.published!==false).sort((a,b)=>(a.sort_order||0)-(b.sort_order||0)).map(b=>`<div class="book" onclick="openDbBook('${esc(b.id)}')"><div class="cover">${b.cover_url?`<img src="${esc(b.cover_url)}" alt="">`:'<div style="height:100%;display:grid;place-items:center;color:#efb548;font:24px Amiri">مِداد</div>'}</div><div class="book-title">${esc(b.title)}</div><div class="author">${esc(b.author||'محمود')}</div></div>`).join('');
      }
      window.MIDAD_CONTENT=d;
      const first=(d.books||[]).find(b=>b.published!==false);
      const ch=(d.chapters||[]).filter(x=>x.published!==false && (!first || x.book_id===first.id)).sort((a,b)=>(a.sort_order||0)-(b.sort_order||0));
      if(ch.length) window.chapters=ch.map(x=>[x.chapter_label||String(x.sort_order),x.title,x.body]);
    }catch(e){console.warn('Midad content fallback',e)}
  }
  window.openDbBook=async function(bookId){
    try{const r=await fetch('/api/content',{cache:'no-store'});const d=await r.json();const ch=(d.chapters||[]).filter(x=>x.published!==false&&x.book_id===bookId).sort((a,b)=>(a.sort_order||0)-(b.sort_order||0));if(ch.length){window.chapters=ch.map(x=>[x.chapter_label||String(x.sort_order),x.title,x.body]);startReading();}}catch(e){toast('تعذر تحميل الرواية الآن')}
  };
  load();
})();
