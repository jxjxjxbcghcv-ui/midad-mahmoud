module.exports=async(req,res)=>{res.setHeader('Set-Cookie','midad_admin=; Path=/; HttpOnly; Secure; SameSite=Lax; Max-Age=0');return res.status(200).json({ok:true})};
